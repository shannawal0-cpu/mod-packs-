
# Dynamic lights follow player
execute as @a[hasitem={item=torch,location=slot.weapon.mainhand}] at @s run fill ~-1 ~-1 ~-1 ~1 ~1 ~1 air replace light_block
execute as @a[hasitem={item=lantern,location=slot.weapon.mainhand}] at @s run fill ~-1 ~-1 ~-1 ~1 ~1 ~1 air replace light_block
execute as @a[hasitem={item=soul_lantern,location=slot.weapon.mainhand}] at @s run fill ~-1 ~-1 ~-1 ~1 ~1 ~1 air replace light_block

execute as @a[hasitem={item=torch,location=slot.weapon.mainhand}] at @s run setblock ~ ~ ~ light_block 6
execute as @a[hasitem={item=lantern,location=slot.weapon.mainhand}] at @s run setblock ~ ~ ~ light_block 6
execute as @a[hasitem={item=soul_lantern,location=slot.weapon.mainhand}] at @s run setblock ~ ~ ~ light_block 6


# Campfires placed start extinguished
execute as @a at @s run fill ~-3 ~-3 ~-3 ~3 ~3 ~3 campfire ["lit"=false] replace campfire ["lit"=true]
execute as @a at @s run fill ~-3 ~-3 ~-3 ~3 ~3 ~3 soul_campfire ["lit"=false] replace soul_campfire ["lit"=true]


# Flint & steel 50% success chance (approximate random removal of fire)
scoreboard players random @a flintChance 0 1
execute as @a[scores={flintChance=1}] at @s run fill ~-2 ~-2 ~-2 ~2 ~2 ~2 air replace fire
